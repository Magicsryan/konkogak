<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->setAutoRoute(true);
$routes->get('/', 'Home::index');

$routes->get('/login', 'Home::login');
$routes->post('/login', 'Home::do_login');

$routes->get('/register', 'Home::register');
$routes->post('/register', 'Home::do_register');
