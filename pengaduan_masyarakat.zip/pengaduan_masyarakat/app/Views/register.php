<?= $this->extend('layouts/master_auth') ?>

<?= $this->section('content') ?>

<?php
if (session()->getFlashdata('error')) {
  echo '<div class="alert alert-danger" role="alert">';
  echo session()->getFlashdata('error');
  echo '</div>';
}

if (session()->getFlashdata('success')) {
  echo '<div class="alert alert-success" role="alert">';
  echo session()->getFlashdata('success');
  echo '</div>';
}
?>

<form method="POST" action="<?= base_url('register') ?>" class="needs-validation" novalidate="">
  <div class="form-group">
    <label for="email">Username</label>
    <input id="username" type="text" class="form-control" name="username" tabindex="1" required autofocus>
    <div class="invalid-feedback">
      Please fill in your email
    </div>
  </div>

  <div class="form-group">
    <label for="email">Email</label>
    <input id="email" type="email" class="form-control" name="email" tabindex="1" required autofocus>
    <div class="invalid-feedback">
      Please fill in your email
    </div>
  </div>

  <div class="form-group">
    <div class="d-block">
      <label for="password" class="control-label">Password</label>
    </div>
    <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
    <div class="invalid-feedback">
      please fill in your password
    </div>
  </div>

  <div class="form-group">
    <div class="d-block">
      <label for="password" class="control-label">Confirm Password</label>
    </div>
    <input id="cpassword" type="password" class="form-control" name="cpassword" tabindex="2" required>
    <div class="invalid-feedback">
      please fill in your password
    </div>
  </div>

  <div class="form-group">
    <div class="custom-control custom-checkbox">
      <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember-me">
      <label class="custom-control-label" for="remember-me">Remember Me</label>
    </div>
  </div>

  <div class="form-group text-right">

    <button type="submit" class="btn btn-primary btn-lg btn-icon icon-right" tabindex="4">
      Register
    </button>
  </div>

  <div class="mt-5 text-center">
    Already have an account? <a href="<?= base_url('login') ?>">Login</a>
  </div>
</form>
<?= $this->endSection() ?>