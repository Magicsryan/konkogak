<?php

namespace App\Models;

use CodeIgniter\Model;

class TanggapanModel extends Model
{
    protected $table            = 'tanggapan';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    protected $allowedFields    = ['pengaduan_id', 'tgl_tanggapan', 'tanggapan', 'petugas_id'];
    protected $useTimestamps = true;
}
