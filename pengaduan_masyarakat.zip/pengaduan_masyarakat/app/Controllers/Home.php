<?php

namespace App\Controllers;

use App\Models\UserModel;

class Home extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function index(): string
    {
        return view('layouts/master_auth');
    }

    public function login(): string
    {
        return view('login');
    }

    public function do_login()
    {
        $username = $this->request->getPost('login');
        $password = $this->request->getPost('password');

        $user = $this->userModel->where('username', $username)->orWhere('email', $username)->first();

        if ($user) {
            if (password_verify($password, $user->password)) {
                session()->set('username', $user->username);
                session()->set('role', $user->role);
                return redirect()->to('/dashboard');
            } else {
                session()->setFlashdata('error', 'Password salah');
                return redirect()->to('/login');
            }
        } else {
            session()->setFlashdata('error', 'Username tidak ditemukan');
            return redirect()->to('/login');
        }
    }

    public function register(): string
    {
        return view('register');
    }

    public function do_register()
    {
        $username = $this->request->getPost('username');
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
        $cpassword = $this->request->getPost('cpassword');

        $user = $this->userModel->where('username', $username)->orWhere('email', $email)->first();

        if ($user) {
            session()->setFlashdata('error', 'Username atau email sudah terdaftar');
            return redirect()->to('/register');
        } else {
            if ($password == $cpassword) {
                $this->userModel->insert([
                    'username' => $username,
                    'email' => $email,
                    'password' => password_hash($password, PASSWORD_DEFAULT),
                    'role' => 'masyarakat'
                ]);

                session()->setFlashdata('success', 'Registrasi berhasil');
                return redirect()->to('/login');
            } else {
                session()->setFlashdata('error', 'Password tidak sama');
                return redirect()->to('/register');
            }
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
