<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Masyarakat extends BaseController
{
    public function index()
    {
        //
    }
}
